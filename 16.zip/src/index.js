import React from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';

import './index.scss';

import store from './redux/reduxStore';
import App from './components/App/App';
import {loadCommentsActionCreator} from './redux/reducerComments';

let rerender = state => {
  console.log (state);

  ReactDOM.render (
    <React.StrictMode>
      <App state={store.getState ()} dispatch={store.dispatch.bind (store)} />
    </React.StrictMode>,
    document.getElementById ('root')
  );
};

// Загружаем сохранённые комментарии
store.dispatch (loadCommentsActionCreator ());

// Первично отрисовываем страницу
rerender (store.getState ());

// Отдаём наш rerender в state
store.subscribe (() => {
  let state = store.getState ();
  rerender (state);
});

// Работа в офлайн
serviceWorker.register (store);
