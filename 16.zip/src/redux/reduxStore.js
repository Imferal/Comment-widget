import reducerComments from './reducerComments';
// import reducerCommentNew from './reducerCommentNew';

const initialState = {
  commentsNew: {
    editableCommentAuthor: '',
    editableCommentText: '',
  },
  comments: {
    commentsData: [],
  },
};

// const {createStore, combineReducers} = require ('redux');
const {createStore} = require ('redux');

let store = createStore (reducerComments, initialState);

export default store;
