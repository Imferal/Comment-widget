import React from 'react';

export default function Footer () {
  return (
    <footer>
      <h3>module 16/18</h3>
    </footer>
  );
}
