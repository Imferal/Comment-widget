import React from 'react'

export default function Header() {
    return (
        <header>
            <h1>Comments widget</h1>
        </header>
    )
}
